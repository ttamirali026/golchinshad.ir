!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):"object"==typeof exports?a(require("jquery")):a(jQuery)}(function(a){function b(a){return h.raw?a:encodeURIComponent(a)}function c(a){return h.raw?a:decodeURIComponent(a)}function d(a){return b(h.json?JSON.stringify(a):String(a))}function e(a){0===a.indexOf('"')&&(a=a.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\"));try{return a=decodeURIComponent(a.replace(g," ")),h.json?JSON.parse(a):a}catch(b){}}function f(b,c){var d=h.raw?b:e(b);return a.isFunction(c)?c(d):d}var g=/\+/g,h=a.cookie=function(e,g,i){if(void 0!==g&&!a.isFunction(g)){if(i=a.extend({},h.defaults,i),"number"==typeof i.expires){var j=i.expires,k=i.expires=new Date;k.setTime(+k+864e5*j)}return document.cookie=[b(e),"=",d(g),i.expires?"; expires="+i.expires.toUTCString():"",i.path?"; path="+i.path:"",i.domain?"; domain="+i.domain:"",i.secure?"; secure":""].join("")}for(var l=e?void 0:{},m=document.cookie?document.cookie.split("; "):[],n=0,o=m.length;o>n;n++){var p=m[n].split("="),q=c(p.shift()),r=p.join("=");if(e&&e===q){l=f(r,g);break}e||void 0===(r=f(r))||(l[q]=r)}return l};h.defaults={},a.removeCookie=function(b,c){return void 0===a.cookie(b)?!1:(a.cookie(b,"",a.extend({},c,{expires:-1})),!a.cookie(b))}});

(function($) { $(document).ready(function(){
jQuery(".menu_right ul li").hover(function(){
var n=jQuery(this).find(" > ul");n.length>0&&jQuery(window).width()>900&&n.stop().slideDown(180)},
function(){var n=jQuery(this).find(" > ul");n.length>0&&jQuery(window).width()>900&&n.stop().slideUp(200)
});
$('.tabs-nav a').on('click', function (event) {
    event.preventDefault();
    $('.tab-active').removeClass('tab-active');
    $(this).parent().addClass('tab-active');
    $('.tabs-stage div').hide();
    $($(this).attr('href')).show();
});
$('.tabs-nav a:first').trigger('click');
$('.tabs-nav2 a').on('click', function (event) {
    event.preventDefault();
    $('.tab-active2').removeClass('tab-active2');
    $(this).parent().addClass('tab-active2');
    $('.tabs-stage2 div').hide();
    $($(this).attr('href')).show();
});
$('.tabs-nav2 a:first').trigger('click');
$('.tabs-nav3 a').on('click', function (event) {
    event.preventDefault();
    $('.tab-active3').removeClass('tab-active3');
    $(this).parent().addClass('tab-active3');
    $('.tabs-stage3 div').hide();
    $($(this).attr('href')).show();
});
$('.tabs-nav3 a:first').trigger('click');
$('.tabs-nav4 a').on('click', function (event) {
    event.preventDefault();
    $('.tab-active4').removeClass('tab-active4');
    $(this).parent().addClass('tab-active4');
    $('.tabs-stage4 div').hide();
    $($(this).attr('href')).show();
});
$('.tabs-nav4 a:first').trigger('click');
$(document).scroll(function(){
var y = $(this).scrollTop();
if (y > 600){ $('.top_page').fadeIn(); } else{ $('.top_page').fadeOut(); }});
$('.top_page').click( function(){ $('body,html').animate({ scrollTop: 0 },600); return false; });
$(".toggle_modes").click(function(){
$(".toggle_modes").toggleClass("active");
$("body").toggleClass("night");
$.cookie("toggle_modes", $(".toggle_modes").hasClass('active'),{ path: '/' });
});
if ($.cookie("toggle_modes") == "true"){
$(".toggle_modes").addClass("active");
$("body").addClass("night");
}
$('body').click(function(event) {
  if (!$('.searches_mobile').is(event.target) && $('.searches_mobile').has(event.target).length === 0) {
    $('.searches_mobile').slideUp();
    $('.search_mobile_box').removeClass('active');
  }
});
$('.search_mobile_box').click(function(event) {
  event.stopPropagation()
  $(this).toggleClass('active');
  $(".searches_mobile").slideToggle();
});
$(document).ready(function(){
$('ul.tree.dhtml').hide();
if(!$('ul.tree.dhtml').hasClass('dynamized')){
$('ul.tree.dhtml ul').prev().before("<span class='grower OPEN'> </span>");
$('ul.tree.dhtml ul li:last-child, ul.tree.dhtml li:last-child').addClass('last');
$('ul.tree.dhtml span.grower.OPEN').addClass('CLOSE').removeClass('OPEN').parent().find('ul:first').hide();
$('ul.tree.dhtml').show();
$('ul.tree.dhtml .selected').parents().each(
function(){if($(this).is('ul')) toggleBranch($(this).prev().prev(),true);});
toggleBranch($('ul.tree.dhtml .selected').prev(),true);
$('ul.tree.dhtml span.grower').click(function(){toggleBranch($(this));});
$('ul.tree.dhtml').addClass('dynamized');
$('ul.tree.dhtml').removeClass('dhtml');
}});
function openBranch(jQueryElement,noAnimation){
jQueryElement.addClass('OPEN').removeClass('CLOSE');
if(noAnimation) jQueryElement.parent().find('ul:first').show();
else jQueryElement.parent().find('ul:first').slideDown();
}
function closeBranch(jQueryElement,noAnimation){
jQueryElement.addClass('CLOSE').removeClass('OPEN');
if(noAnimation) jQueryElement.parent().find('ul:first').hide();
else jQueryElement.parent().find('ul:first').slideUp();
}
function toggleBranch(jQueryElement,noAnimation){
if(jQueryElement.hasClass('OPEN')) closeBranch(jQueryElement,noAnimation);
else openBranch(jQueryElement,noAnimation);};
$('#cssmenu li.has-sub>a').on('click', function(){
    $(this).removeAttr('href');
    var element = $(this).parent('li');
    if (element.hasClass('open')) {
      element.removeClass('open');
      element.find('li').removeClass('open');
      element.find('ul').slideUp();
    }
    else {
      element.addClass('open');
      element.children('ul').slideDown();
      element.siblings('li').children('ul').slideUp();
      element.siblings('li').removeClass('open');
      element.siblings('li').find('li').removeClass('open');
      element.siblings('li').find('ul').slideUp();
    }
  });
$('#cssmenu>ul>li.has-sub>a').append('<span class="holder"></span>');
$(".navicon").click(function(){ $(".mobiles_menu").animate({marginRight:"0px"},200,"linear"); runmenu=1; });
$(".bodydeactive").click(function(){ $(".mobiles_menu").animate({marginRight:"-232px"},200,"linear"); });
$(".navicon").click(function(){ 
$(".bodydeactive").fadeIn(400), $(".mobile_box").animate({marginRight:"0px"},200,"linear") });
$(".bodydeactive").click(function(){
$(".mobile_box").animate({marginRight:"0px"},200,"linear"), $(".bodydeactive").fadeOut(400)
});
	
$("audio").on("play",function(){
$("audio").not(this).each(function(index, audio){audio.pause();});
});

});
}(jQuery));