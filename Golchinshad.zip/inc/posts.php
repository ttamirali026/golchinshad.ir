<?php if(wp_is_mobile('')){ ?>
<article class="mobile_article">
<header>
<figure><a rel="noreferrer noopener nofollow" href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb3',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="70" height="70" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?></a></figure>
<h2><a rel="noreferrer noopener" href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></h2>
</header>
<footer>
<?php if(function_exists('the_views')){ ?>
<div class="mobile_ft_box"><i class="icofont-eye-alt"></i> <?php the_views(); ?></div><?php } ?>
</footer>
<div class="clear"></div>
</article>
<?php } else{ ?>
<article class="article_box">
<header>
<?php $post_id=get_the_ID(); get_template_part('inc/article_icon'); ?>
<h2><a rel="noreferrer noopener" href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></h2>
<?php if(function_exists('the_views')){ ?>
<div class="view_box"><i class="icofont-eye-alt"></i> <?php the_views(); ?></div><?php } ?>
<div class="clear"></div>
</header>
<div class="article_txt">
<?php the_content(''); ?>
<?php $timgi = ot_get_option('timgi'); if('off' != $timgi){ if(has_post_thumbnail()){
the_post_thumbnail('full',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="500" height="500" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } } ?>	
<div class="clear"></div>
</div>
<?php if(is_home()){ $ply_ons = ot_get_option('ply_on'); if('off' != $ply_ons){ ?>
<?php $dlm128=get_post_meta($post_id,'music128',true); $online=get_post_meta($post_id,'online',true); 
if( (isset($online) && !empty($online)) || (isset($dlm128) && !empty($dlm128)) ){ ?>
<div class="clear"></div>
<div class="article_online_play">
<audio preload="none" src="<?php if(isset($online) && !empty($online)){echo $online;} else{echo $dlm128;} ?>" controls="controls">مرورگر شما از پخش کننده آنلاین پشتیبانی نمی کند.</audio>
<div class="clear"></div>
</div>
<?php } else{ ?>
<div class="clear"></div>
<a rel="noreferrer noopener" target="_blank" href="<?php the_permalink(); ?>" class="article_url_more">ادامه و دانلود</a>	
<?php } ?>
<?php }} else { $ply1_ons = ot_get_option('ply1_on'); if('off' != $ply1_ons){ ?> 
<?php $dlm128=get_post_meta($post_id,'music128',true); $online=get_post_meta($post_id,'online',true); 
if( (isset($online) && !empty($online)) || (isset($dlm128) && !empty($dlm128)) ){ ?>
<div class="clear"></div>
<div class="article_online_play">
<audio preload="none" src="<?php if(isset($online) && !empty($online)){echo $online;} else{echo $dlm128;} ?>" controls="controls">مرورگر شما از پخش کننده آنلاین پشتیبانی نمی کند.</audio>
<div class="clear"></div>
</div>
<?php } else{ ?>
<div class="clear"></div>
<a rel="noreferrer noopener" target="_blank" href="<?php the_permalink(); ?>" class="article_url_more">ادامه و دانلود</a>	
<?php } ?>	
<?php }} ?>
<footer>
<div class="article_ft_box"> <i class="icofont-clock-time"></i> <?php the_time('j F Y'); ?> </div>
<div class="article_ft_box"> <i class="icofont-archive"></i> <?php the_category(' , '); ?> </div>
<a rel="noreferrer noopener nofollow" class="article_ft_more" href="<?php the_permalink(); ?>">ادامه و دانلود</a>
<?php include_once(ABSPATH .'wp-admin/includes/plugin.php'); if(is_plugin_active('thumbs-rating/thumbs-rating.php')){ ?><div class="article_like_box"><?php echo do_shortcode('[thumbs-rating-buttons]');?></div> <?php } ?>
<div class="clear"></div>
</footer>
<div class="clear"></div>
</article>
<?php } ?>