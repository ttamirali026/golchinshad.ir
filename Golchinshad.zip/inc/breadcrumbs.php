<?php if(function_exists('yoast_breadcrumb')){ yoast_breadcrumb('
<div class="article_box y_breadcrumb padding15">
<i class="icofont-location-pin"></i> <p id="breadcrumbs">','</p><div class="clear"></div></div>'); } ?>