<article class="music_posts2">
<header>
<h2><a rel="noreferrer noopener" href="<?php the_permalink(); ?>">
<?php 
$artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){ ?>
<?php echo $artist; ?> - <?php echo $track; } else{ the_title(''); } ?>
</a></h2>
</header>
<figure><a rel="noreferrer noopener nofollow" href="<?php $post_id=get_the_ID(); the_permalink(); ?>">
<?php  if(has_post_thumbnail()){
if(wp_is_mobile()){
the_post_thumbnail('thumb4',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().''));
}else{the_post_thumbnail('thumb5',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().''));}
} else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="198" height="198" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?></a></figure>	
<footer>
<?php if(function_exists('the_views')){ ?>
<div class="view_box_right"><i class="icofont-eye-alt"></i> <?php the_views(); ?></div><?php } ?>
<?php include_once(ABSPATH .'wp-admin/includes/plugin.php'); if(is_plugin_active('thumbs-rating/thumbs-rating.php')){ ?><div class="article_like_box"><?php echo do_shortcode('[thumbs-rating-buttons]');?></div> <?php } ?>
<?php if(is_home()){ $ply_ons = ot_get_option('ply_on'); if('off' != $ply_ons){ ?>
<?php $dlm128=get_post_meta($post_id,'music128',true); $online=get_post_meta($post_id,'online',true); 
if( (isset($online) && !empty($online)) || (isset($dlm128) && !empty($dlm128)) ){ ?>
<div class="clear"></div>
<div class="article_online_play">
<audio preload="none" src="<?php if(isset($online) && !empty($online)){echo $online;} else{echo $dlm128;} ?>" controls="controls">مرورگر شما از پخش کننده آنلاین پشتیبانی نمی کند.</audio>
<div class="clear"></div>
</div>
<?php } else{ ?>
<div class="clear"></div>
<a rel="noreferrer noopener" target="_blank" href="<?php the_permalink(); ?>" class="article_url_more">ادامه و دانلود</a>	
<?php } ?>
<?php }} else { $ply1_ons = ot_get_option('ply1_on'); if('off' != $ply1_ons){ ?> 
<?php $dlm128=get_post_meta($post_id,'music128',true); $online=get_post_meta($post_id,'online',true); 
if( (isset($online) && !empty($online)) || (isset($dlm128) && !empty($dlm128)) ){ ?>
<div class="clear"></div>
<div class="article_online_play">
<audio preload="none" src="<?php if(isset($online) && !empty($online)){echo $online;} else{echo $dlm128;} ?>" controls="controls">مرورگر شما از پخش کننده آنلاین پشتیبانی نمی کند.</audio>
<div class="clear"></div>
</div>
<?php } else{ ?>
<div class="clear"></div>
<a rel="noreferrer noopener" target="_blank" href="<?php the_permalink(); ?>" class="article_url_more">ادامه و دانلود</a>	
<?php } ?>	
<?php }} ?>	
<div class="clear"></div>
</footer>
<div class="clear"></div>
</article>