<?php $vipons = ot_get_option('vipon'); if('off' != $vipons){ ?>
<!-- musics_boxs -->
<div class="musics_boxs">
<div class="tarlanweb_center">
<div class="post_box_titr">
<p class="post_box_title"><?php echo ot_get_option('vip_title'); ?></p>
<?php $category_id = ot_get_option('ftcat1'); $category_link = get_category_link($category_id); ?>
<a class="more_posts" rel="noreferrer noopener" href="<?php echo esc_url($category_link); ?>">بیشتر <i class="icofont-long-arrow-left"></i></a>
<div class="clear"></div>
</div>
<?php $cat_ft1=ot_get_option('ftcat1'); $num_ft1=ot_get_option('ft_num');
$my_custom_query= new WP_Query(array(
'post_type' => 'post',
'post_status' => 'publish',
'cat'   =>  $cat_ft1,
'order' => 'DESC',
'orderby' => 'ID',
'posts_per_page' =>$num_ft1
)); if($my_custom_query->have_posts()) : ?>
<div class="posts_lists">
<ul>
<?php while($my_custom_query->have_posts()) : $my_custom_query->the_post(); $post_id=get_the_ID(); ?>
<li>
<article class="music_posts">
<header>
<figure><a rel="noreferrer noopener" href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
if(wp_is_mobile()){
the_post_thumbnail('thumb4',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().''));
}else{the_post_thumbnail('thumb1',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().''));}
} else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="169" height="169" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?></a></figure>
<?php $video1080=get_post_meta($post_id,'video1080',true); $video720=get_post_meta($post_id,'video720',true);
$video480=get_post_meta($post_id,'video480',true); $film1080=get_post_meta($post_id,'film1080',true);
$film720=get_post_meta($post_id,'film720',true); $film480=get_post_meta($post_id,'film480',true);
if( (isset($video1080) && !empty($video1080)) || (isset($video720) && !empty($video720)) || (isset($video480) && !empty($video480)) || (isset($film1080) && !empty($film1080)) || (isset($film720) && !empty($film720)) || (isset($film480) && !empty($film480)) ){ ?>
<div class="music_posts_type"><i class="icofont-video-alt"></i></div>
<?php } else{ ?>
<div class="music_posts_type"><i class="icofont-music"></i></div>
<?php } ?>
</header>
<footer>
<h2><a rel="noreferrer noopener" href="<?php the_permalink(); ?>">
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){ ?>
<span class="artist_names"><?php echo $artist; ?></span>
<span class="song_names"><?php echo $track; ?></span>
<?php } else{ ?><span class="titlles_rf"><?php the_title(''); ?></span><?php } ?>
</a></h2>
</footer>
<div class="clear"></div>
</article>
</li>
<?php endwhile; ?>
</ul>
</div>
<?php endif; wp_reset_query(); ?>
<div class="clear"></div>
</div>
</div>
<!-- musics_boxs -->
<?php } ?>

<?php if(!is_single()){ if(ot_get_option('ads_imp') !=""){ ?>
<div class="img_top_ads">
<?php echo ot_get_option('ads_imp'); ?>
<div class="clear"></div>
</div>
<?php } else{ echo '<div class="clear2"></div>'; } } ?>