<!-- index_posts -->
<div class="full_posts_box">
<div class="tarlanweb_center">
	
<?php if(is_home()){ ?> 
<div class="full_box_titr cats_dets">
<strong class="fontsize30">آخرین ارسال ها</strong>
<div class="clear"></div>
</div>
<?php } ?>
	
<?php if(is_category()){ ?> 
<div class="full_box_titr cats_dets">
<h1><?php echo single_cat_title(''); ?></h1>
<div class="article_box_txtc">
<?php echo category_description(); ?>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<?php } ?>

<?php if(is_search()){ ?> 
<div class="full_box_titr cats_dets">
<h1>نتایج جستجو عبارت : <?php printf(the_search_query()); ?></h1>
<div class="clear"></div>
</div>
<?php } ?>

<?php if(is_tag()){ ?>
<div class="full_box_titr cats_dets">
<h1><?php echo single_tag_title(''); ?></h1>
<div class="article_box_txtc">
<?php echo tag_description(); ?>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<?php } ?>
<?php if(!is_home()){if(function_exists('yoast_breadcrumb')){yoast_breadcrumb('<p id="breadcrumbs">','</p>');}} ?>
	
<div class="index_posts">
<?php if(have_posts()) : ?>
<ul>
<?php while(have_posts()) : the_post(); ?>
<li><?php get_template_part('inc/full_post'); ?></li>
<?php endwhile; ?>
</ul>
<?php endif; ?>
</div>
<div class="clear"></div>
<?php get_template_part('inc/pagination'); ?>
<div class="clear"></div>
</div>
</div>
<!-- index_posts -->