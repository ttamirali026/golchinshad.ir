<?php
/**
 * Initialize the custom Meta Boxes. 
 */
add_action( 'admin_init', 'custom_meta_boxes' );
/**
 * Meta Boxes demo code.
 *
 * You can find all the available option types in demo-theme-options.php.
 *
 * @return    void
 * @since     2.0
 */
function custom_meta_boxes() {
  /**
   * Create a custom meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
$dl_kianoosh_box = array(
    'id'          => 'demo_meta_box1',
    'title'       => 'تنظیمات',
    'desc'        => 'تنظیمات موزیک را وارد کنید.',
    'pages'       => array('post'),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
array(
'id'=> 'artist',
'label'=>'خواننده',
'desc'=>'نام خواننده را وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=> 'artist2',
'label'=>'خواننده 2',
'desc'=>'اگر اثر با همکاری دو خواننده تولید شده نام خواننده دوم را در این فیلد وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=> 'song',
'label'=>'قطعه',
'desc'=>'نام قطعه را وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=> 'music128',
'label'=>'لینک 128',
'desc'=>'لینک دانلود با کیفیت 128 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'music320',
'label'=>'لینک 320',
'desc'=>'لینک دانلود با کیفیت 320 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=> 'album128',
'label'=>'لینک آلبوم 128',
'desc'=>'لینک دانلود کلی آلبوم با کیفیت 128 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'album320',
'label'=>'لینک 320',
'desc'=>'لینک دانلود کلی آلبوم با کیفیت 320 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=> 'albumt128',
'label'=>'لینک آلبوم 128',
'desc'=>'لینک دانلود تکی آلبوم با کیفیت 128 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'albumt320',
'label'=>'لینک 320',
'desc'=>'لینک دانلود تکی آلبوم با کیفیت 320 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'online',
'label'=>'لینک پلیر',
'desc'=>'لینک آهنگ برای پخش در پلیر را وارد کنید. در صورت خالی بودن لینک دانلود 128 در پلیر قرار میگیرد.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'video1080',
'label'=>'لینک موزیک ویدیو 1080',
'desc'=>'لینک دانلود موزیک ویدیو با کیفیت 1080 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'video720',
'label'=>'لینک موزیک ویدیو 720',
'desc'=>'لینک دانلود موزیک ویدیو با کیفیت 720 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'video480',
'label'=>'لینک موزیک ویدیو 480',
'desc'=>'لینک دانلود موزیک ویدیو با کیفیت 480 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'film1080',
'label'=>'لینک فیلم 1080',
'desc'=>'لینک دانلود فیلم با کیفیت 1080 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'film720',
'label'=>'لینک فیلم 720',
'desc'=>'لینک دانلود فیلم با کیفیت 720 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),
array(
'id'=>'film480',
'label'=>'لینک فیلم 480',
'desc'=>'لینک دانلود فیلم با کیفیت 480 را به همراه http:// وارد کنید.',
'std'=>'',
'type'=>'text',
),

array(
'id'=>'music_txt',
'label'=>'متن ترانه',
'desc'=>'متن ترانه را وارد کنید.<br>در هر خط یک بیت را بدون فاصله با خط بعدی وارد کنید.',
'std'=>'',
'type'=>'textarea',
),

));
/**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  if ( function_exists( 'ot_register_meta_box' ) )
    ot_register_meta_box( $dl_kianoosh_box );
}