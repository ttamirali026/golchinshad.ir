<?php $post_id=get_the_ID(); global $post_id;
$video1080=get_post_meta($post_id,'video1080',true); $video720=get_post_meta($post_id,'video720',true);
$video480=get_post_meta($post_id,'video480',true); $film1080=get_post_meta($post_id,'film1080',true);
$film720=get_post_meta($post_id,'film720',true); $film480=get_post_meta($post_id,'film480',true);
if( (isset($video1080) && !empty($video1080)) || (isset($video720) && !empty($video720)) || (isset($video480) && !empty($video480)) || (isset($film1080) && !empty($film1080)) || (isset($film720) && !empty($film720)) || (isset($film480) && !empty($film480)) ){ ?><i class="icofont-video-alt"></i>
<?php } else{ ?><i class="icofont-music-alt"></i><?php } ?>