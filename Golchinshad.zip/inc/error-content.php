<article class="article_box">
<header>
<i class="icofont-exclamation-tringle"></i>
<h1>خطای 404 !</h1>
<div class="clear"></div>
</header>
<div class="article_txt">

<img class="aligncenter" src="<?php bloginfo('template_url'); ?>/images/error404.jpg" width="626" height="380" alt="خطای 404" title="خطای 404">
<p>خطای 404 نشان دهنده اینست که مطلبی که به دنبال آن هستید وجود ندارد.<br> ممکن است حذف شده باشد و یا اصلا نوشته نشده باشد. <br> اگر مطمعن  هستید قبلا چنین مطلبی در سایت منتشر شده، از طریق فرم تماس و یا راه های ارتباطی با مدیران سایت تماس بگیرید.</p>
<p>بعد از <span id="count"></span> ثانیه به صورت خودکار به صفحه اصلی هدایت میشوید.</p>
<script>
(function($) { $(document).ready(function(){
window.onload = function(){(function(){ var counter = 15; setInterval(function(){ counter--;
if(counter >= 0){span = document.getElementById("count");
span.innerHTML = counter;} if(counter === 0){clearInterval(counter);}}, 1000); })(); }
function go2NewUrl(newUrl, sec){setTimeout("location.href='" + newUrl + "'", sec * 1000);}
go2NewUrl('<?php bloginfo('url'); ?>', 15);
});
}(jQuery));
</script>

<div class="clear"></div>
</div>
<div class="clear"></div>
</article>