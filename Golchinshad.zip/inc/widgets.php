<?php 
function rkianosh_load_widget(){ register_widget( 'tarlanweb_ir_newp' ); }
add_action( 'widgets_init', 'rkianosh_load_widget' ); 
class tarlanweb_ir_newp extends WP_Widget {
function __construct() {
parent::__construct(
'tarlanweb_ir_newp', '(اختصاصی) جدیدترین مطالب', 
array('description' => 'ابزارک نمایش جدیدترین مطالب با تصویر شاخص') 
);
}
// Creating widget front-end
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
$post_numbers = apply_filters( 'widget_numbers', $instance['post_numbers'] );
$targets = $instance[ 'targets' ] ? 'true' : 'false';
// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<?php global $wp_query; 
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'orderby' => 'id',
'order' => 'DESC',
'post_status' => 'publish',
);
$wp_query = new WP_Query($arms); if($wp_query->have_posts()) : ?>
<ul class="aside_box_thu">
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb2',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="50" height="50" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?>
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); 
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?>
<span class="sides_dets">
<?php if(function_exists('the_views')){ ?>
<span> <i class="icofont-eye-alt"></i> <?php the_views(); ?></span><?php } ?>
</span>
</a></li>
<?php endwhile; ?>
</ul>
<?php endif; wp_reset_query(); ?>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'جدیدترین موسیقی ها', 'tarlanweb_ir_newp_domain' );
}
if ( isset( $instance[ 'post_numbers' ] ) ) {
$post_numbers = $instance[ 'post_numbers' ];
}
else {
$post_numbers = __( '7', 'tarlanweb_ir_newp_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان: </label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_numbers' ); ?>">تعداد مطالب قابل نمایش:</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_numbers' ); ?>" name="<?php echo $this->get_field_name( 'post_numbers' ); ?>" type="text" value="<?php echo esc_attr( $post_numbers ); ?>" />
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'targets' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'targets' ); ?>" name="<?php echo $this->get_field_name( 'targets' ); ?>"/> 
<label for="<?php echo $this->get_field_id( 'targets' ); ?>">باز شدن لینک در تب جدید</label>
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_numbers'] = ( ! empty( $new_instance['post_numbers'] ) ) ? strip_tags( $new_instance['post_numbers'] ) : '';
$instance[ 'targets' ] = $new_instance[ 'targets' ];
return $instance;
}
}
// end ne post by thumbnail
function rkianosh1_load_widget(){ register_widget( 'tarlanweb_ir_newp1' ); }
add_action( 'widgets_init', 'rkianosh1_load_widget' ); 
class tarlanweb_ir_newp1 extends WP_Widget {
function __construct() {
parent::__construct(
'tarlanweb_ir_newp1','(اختصاصی) جدیدترین مطالب', 
array('description' => 'ابزارک نمایش جدیدترین مطالب بدون تصویر شاخص') 
);
}
// Creating widget front-end
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
$post_numbers = apply_filters( 'widget_numbers', $instance['post_numbers'] );
$targets = $instance[ 'targets' ] ? 'true' : 'false';
// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<?php global $wp_query; 
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'orderby' => 'id',
'order' => 'DESC',
'post_status' => 'publish',
);
$wp_query = new WP_Query($arms); if($wp_query->have_posts()) : ?>
<ul>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); 
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?></a></li>
<?php endwhile; ?>
</ul>
<?php endif; wp_reset_query(); ?>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'جدیدترین موسیقی ها', 'tarlanweb_ir_newp_domain' );
}
if ( isset( $instance[ 'post_numbers' ] ) ) {
$post_numbers = $instance[ 'post_numbers' ];
}
else {
$post_numbers = __( '7', 'tarlanweb_ir_newp_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان: </label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_numbers' ); ?>">تعداد مطالب قابل نمایش:</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_numbers' ); ?>" name="<?php echo $this->get_field_name( 'post_numbers' ); ?>" type="text" value="<?php echo esc_attr( $post_numbers ); ?>" />
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'targets' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'targets' ); ?>" name="<?php echo $this->get_field_name( 'targets' ); ?>"/> 
<label for="<?php echo $this->get_field_id( 'targets' ); ?>">باز شدن لینک در تب جدید</label>
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_numbers'] = ( ! empty( $new_instance['post_numbers'] ) ) ? strip_tags( $new_instance['post_numbers'] ) : '';
$instance[ 'targets' ] = $new_instance[ 'targets' ];
return $instance;
}
}
// end new posts by title
function tarlanweb_load_widget(){register_widget('tarlanweb_ir_popular');}
add_action( 'widgets_init', 'tarlanweb_load_widget'); 
class tarlanweb_ir_popular extends WP_Widget {
function __construct(){
parent::__construct(
'tarlanweb_ir_popular','(اختصاصی) موسیقی محبوب (بازدید)', 
array('description' => 'ابزارک نمایش موسیقی های محبوب بر اساس بازدید') 
);
}
// Creating widget front-end
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
$post_numbers = apply_filters( 'widget_numbers', $instance['post_numbers'] );
$targets = $instance[ 'targets' ] ? 'true' : 'false';
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<ul class='tabs-nav'>
<li><a href="#week_pop">هفته</a></li>
<li><a href="#month_pop">ماه</a></li>
<li><a href="#year_pop">سال</a></li>
</ul>
<div class="tabs-stage">
<div class="aside_box_content" style="display: block;" id="week_pop">
<ul>
<?php global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => 'views',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '1 week ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?></a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li><?php _e( 'چیزی برای نمایش وجود ندارد' ); ?></li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
<div class="aside_box_content" style="display: none;" id="month_pop">
<ul> 
<?php  global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => 'views',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '1 month ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>"><?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?></a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li><?php _e( 'چیزی برای نمایش وجود ندارد' ); ?></li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
<div class="aside_box_content" style="display: none;" id="year_pop">
<ul>
<?php global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => 'views',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '11 month ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>"><?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?></a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li><?php _e( 'چیزی برای نمایش وجود ندارد' ); ?></li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
</div>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'پربازدیدترین موسیقی ها', 'tarlanweb_ir_popular_domain' );
}
if ( isset( $instance[ 'post_numbers' ] ) ) {
$post_numbers = $instance[ 'post_numbers' ];
}
else {
$post_numbers = __( '7', 'tarlanweb_ir_popular_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان :</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_numbers' ); ?>">تعداد مطالب قابل نمایش:</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_numbers' ); ?>" name="<?php echo $this->get_field_name( 'post_numbers' ); ?>" type="text" value="<?php echo esc_attr( $post_numbers ); ?>" />
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'targets' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'targets' ); ?>" name="<?php echo $this->get_field_name( 'targets' ); ?>"/> 
<label for="<?php echo $this->get_field_id( 'targets' ); ?>">باز شدن لینک در تب جدید</label>
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_numbers'] = ( ! empty( $new_instance['post_numbers'] ) ) ? strip_tags( $new_instance['post_numbers'] ) : '';
$instance[ 'targets' ] = $new_instance[ 'targets' ];
return $instance;
}
}
// end tabs1
function tarlanweb_load_widget2() { register_widget( 'tarlanweb_ir_popular2' ); }
add_action( 'widgets_init', 'tarlanweb_load_widget2' ); 
class tarlanweb_ir_popular2 extends WP_Widget {
function __construct() {
parent::__construct(
'tarlanweb_ir_popular2', '(اختصاصی) موسیقی محبوب (بازدید)', 
array('description' => 'ابزارک نمایش موسیقی های محبوب بر اساس بازدید با تصویر شاخص') 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
$post_numbers = apply_filters( 'widget_numbers', $instance['post_numbers'] );
$targets = $instance[ 'targets' ] ? 'true' : 'false';
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<ul class='tabs-nav2'>
<li><a href="#week_pop1">هفته</a></li>
<li><a href="#month_pop2">ماه</a></li>
<li><a href="#year_pop3">سال</a></li>
</ul>
<div class="tabs-stage2">
<div class="aside_box_content" style="display: block;" id="week_pop1">
<ul class="aside_box_thu">
<?php global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => 'views',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '1 week ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb2',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="50" height="50" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?>
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?>
<span class="sides_dets">
<?php if(function_exists('the_views')){ ?>
<span> <i class="icofont-eye-alt"></i> <?php the_views(); ?></span><?php } ?>
</span>
</a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
<div class="aside_box_content" style="display: none;" id="month_pop2">
<ul class="aside_box_thu"> 
<?php  global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => 'views',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '1 month ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb2',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="50" height="50" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?>
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); 
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?>
<span class="sides_dets">
<?php if(function_exists('the_views')){ ?>
<span> <i class="icofont-eye-alt"></i> <?php the_views(); ?></span><?php } ?>
</span>
</a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
<div class="aside_box_content" style="display: none;" id="year_pop3">
<ul class="aside_box_thu">
<?php global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => 'views',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '11 month ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb2',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="50" height="50" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?>
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?>
<span class="sides_dets">
<?php if(function_exists('the_views')){ ?>
<span> <i class="icofont-eye-alt"></i> <?php the_views(); ?></span><?php } ?>
</span>
</a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
</div>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'پربازدیدترین موسیقی ها', 'tarlanweb_ir_popular_domain' );
}
if ( isset( $instance[ 'post_numbers' ] ) ) {
$post_numbers = $instance[ 'post_numbers' ];
}
else {
$post_numbers = __( '7', 'tarlanweb_ir_popular_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان :</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_numbers' ); ?>">تعداد مطالب قابل نمایش:</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_numbers' ); ?>" name="<?php echo $this->get_field_name( 'post_numbers' ); ?>" type="text" value="<?php echo esc_attr( $post_numbers ); ?>" />
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'targets' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'targets' ); ?>" name="<?php echo $this->get_field_name( 'targets' ); ?>"/> 
<label for="<?php echo $this->get_field_id( 'targets' ); ?>">باز شدن لینک در تب جدید</label>
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_numbers'] = ( ! empty( $new_instance['post_numbers'] ) ) ? strip_tags( $new_instance['post_numbers'] ) : '';
$instance[ 'targets' ] = $new_instance[ 'targets' ];
return $instance;
}
}
// end tab 2 
function tree_cat_post(){register_widget( 'tre_pst_cat' );}
add_action( 'widgets_init', 'tree_cat_post' ); 
class tre_pst_cat extends WP_Widget {
function __construct() {
parent::__construct('tre_pst_cat','(اختصاصی) فهرست درختی', 
array('description' =>'ابزارک نمایش فهرست دلخواه درختی') 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="categories_block">
<ul class="tree dhtml">
<?php wp_nav_menu(
array('theme_location'=>'tree_menu','menu_id'=>'tel09158856205','items_wrap'=>'%3$s','menu_class'=>'td_tarlanweb_ir','container'=>'','title_li'=>'')); ?>
</ul>
<div class="clear"></div>
</div>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {$title = $instance[ 'title' ];}
else {$title = 'دسته بندی مطالب';}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان: </label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}
}
// three end
function arti_cat_post(){register_widget( 'artists_pst' );}
add_action( 'widgets_init', 'arti_cat_post' ); 
class artists_pst extends WP_Widget {
function __construct() {
parent::__construct('artists_pst','(اختصاصی) لیست خوانندگان', 
array('description' =>'ابزارک نمایش لیست خوانندگان') 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="artist_lists">
<ul>
<?php $artista = ot_get_option('siing_t',array()); foreach($artista as $artise){ ?>
<li><a rel="noreferrer noopener" href="<?php echo $artise['siing_u']; ?>"><?php echo $artise['title']; ?> <span><?php echo $artise['siing_n']; ?></span></a></li>
<?php } ?>
</ul>
<div class="clear"></div>
</div>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {$title = $instance[ 'title' ];}
else {$title = 'لیست خوانندگان';}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان: </label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}
}
// arists end
function icon_lists(){register_widget( 'icon_psts' );}
add_action( 'widgets_init', 'icon_lists' ); 
class icon_psts extends WP_Widget {
function __construct() {
parent::__construct('icon_psts','(اختصاصی) لینک دلخواه', 
array('description' =>'ابزارک نمایش لینک های دلخواه') 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="top_links_box">
<?php $sid_url = ot_get_option('sid_url',array()); foreach($sid_url as $artise1){ ?>
<a rel="noreferrer noopener" href="<?php echo $artise1['si_u']; ?>"><i class="icofont-<?php echo $artise1['si_icon']; ?>"></i> <span><?php echo $artise1['title']; ?></span><div class="clear"></div></a>
<?php } ?>
<div class="clear"></div>
</div>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {$title = $instance[ 'title' ];}
else {$title = 'لینک دلخواه';}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان: </label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}
}
// custom links end
function rknos_lod_wigt(){ register_widget( 'tarlanweb_ir_rand' ); }
add_action( 'widgets_init', 'rknos_lod_wigt' ); 
class tarlanweb_ir_rand extends WP_Widget {
function __construct() {
parent::__construct(
'tarlanweb_ir_rand', '(اختصاصی) مطالب تصادفی', 
array('description' => 'ابزارک نمایش مطالب تصادفی با تصویر شاخص') 
);
}
// Creating widget front-end
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
$post_numbers = apply_filters( 'widget_numbers', $instance['post_numbers'] );
$targets = $instance[ 'targets' ] ? 'true' : 'false';
// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<?php global $wp_query; 
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'orderby' => 'rand',
'order' => 'DESC',
'post_status' => 'publish',
);
$wp_query = new WP_Query($arms); if($wp_query->have_posts()) : ?>
<ul class="aside_box_thu">
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb2',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="50" height="50" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?>
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); 
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?>
<span class="sides_dets">
<?php if(function_exists('the_views')){ ?>
<span> <i class="icofont-eye-alt"></i> <?php the_views(); ?></span><?php } ?>
</span>
</a></li>
<?php endwhile; ?>
</ul>
<?php endif; wp_reset_query(); ?>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'مطالب تصادفی', 'tarlanweb_ir_rand_domain' );
}
if ( isset( $instance[ 'post_numbers' ] ) ) {
$post_numbers = $instance[ 'post_numbers' ];
}
else {
$post_numbers = __( '7', 'tarlanweb_ir_rand_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان: </label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_numbers' ); ?>">تعداد مطالب قابل نمایش:</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_numbers' ); ?>" name="<?php echo $this->get_field_name( 'post_numbers' ); ?>" type="text" value="<?php echo esc_attr( $post_numbers ); ?>" />
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'targets' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'targets' ); ?>" name="<?php echo $this->get_field_name( 'targets' ); ?>"/> 
<label for="<?php echo $this->get_field_id( 'targets' ); ?>">باز شدن لینک در تب جدید</label>
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_numbers'] = ( ! empty( $new_instance['post_numbers'] ) ) ? strip_tags( $new_instance['post_numbers'] ) : '';
$instance[ 'targets' ] = $new_instance[ 'targets' ];
return $instance;
}
}
// end random post by thumbnail
function rksh1_lo_wet(){ register_widget( 'tarlanweb_ir_rand1' ); }
add_action( 'widgets_init', 'rksh1_lo_wet' ); 
class tarlanweb_ir_rand1 extends WP_Widget {
function __construct() {
parent::__construct(
'tarlanweb_ir_rand1','(اختصاصی) مطالب تصادفی', 
array('description' => 'ابزارک نمایش مطالب تصادفی بدون تصویر شاخص') 
);
}
// Creating widget front-end
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
$post_numbers = apply_filters( 'widget_numbers', $instance['post_numbers'] );
$targets = $instance[ 'targets' ] ? 'true' : 'false';
// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<?php global $wp_query; 
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'orderby' => 'rand',
'order' => 'DESC',
'post_status' => 'publish',
);
$wp_query = new WP_Query($arms); if($wp_query->have_posts()) : ?>
<ul>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); 
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?></a></li>
<?php endwhile; ?>
</ul>
<?php endif; wp_reset_query(); ?>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'تصادفی', 'tarlanweb_ir_rand_domain' );
}
if ( isset( $instance[ 'post_numbers' ] ) ) {
$post_numbers = $instance[ 'post_numbers' ];
}
else {
$post_numbers = __( '7', 'tarlanweb_ir_rand_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان: </label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_numbers' ); ?>">تعداد مطالب قابل نمایش:</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_numbers' ); ?>" name="<?php echo $this->get_field_name( 'post_numbers' ); ?>" type="text" value="<?php echo esc_attr( $post_numbers ); ?>" />
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'targets' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'targets' ); ?>" name="<?php echo $this->get_field_name( 'targets' ); ?>"/> 
<label for="<?php echo $this->get_field_id( 'targets' ); ?>">باز شدن لینک در تب جدید</label>
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_numbers'] = ( ! empty( $new_instance['post_numbers'] ) ) ? strip_tags( $new_instance['post_numbers'] ) : '';
$instance[ 'targets' ] = $new_instance[ 'targets' ];
return $instance;
}
}
// end random posts by title

function tab_lod_wiet() { register_widget( 'taeb_ir_por2' ); }
add_action( 'widgets_init', 'tab_lod_wiet' ); 
class taeb_ir_por2 extends WP_Widget {
function __construct() {
parent::__construct(
'taeb_ir_por2', '(اختصاصی) موسیقی محبوب (لایک)', 
array('description' => 'ابزارک نمایش موسیقی های محبوب بر اساس لایک با تصویر شاخص') 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
$post_numbers = apply_filters( 'widget_numbers', $instance['post_numbers'] );
$targets = $instance[ 'targets' ] ? 'true' : 'false';
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<ul class='tabs-nav3'>
<li><a href="#week_like1">هفته</a></li>
<li><a href="#month_like2">ماه</a></li>
<li><a href="#year_like3">سال</a></li>
</ul>
<div class="tabs-stage3">
<div class="aside_box_content" style="display: block;" id="week_like1">
<ul class="aside_box_thu">
<?php global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => '_thumbs_rating_up',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '1 week ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb2',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="50" height="50" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?>
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?>
<span class="sides_dets">
<?php if(function_exists('the_views')){ ?>
<span> <i class="icofont-eye-alt"></i> <?php the_views(); ?></span><?php } ?>
<span> <i class="icofont-thumbs-up"></i> <?php
echo $thumbs_up=get_post_meta($post_id,'_thumbs_rating_up',true); ?></span>
</span>
</a></li>
<?php endwhile; else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
<div class="aside_box_content" style="display: none;" id="month_like2">
<ul class="aside_box_thu"> 
<?php  global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => '_thumbs_rating_up',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '1 month ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb2',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="50" height="50" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?>
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); 
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?>
<span class="sides_dets">
<?php if(function_exists('the_views')){ ?>
<span> <i class="icofont-eye-alt"></i> <?php the_views(); ?></span><?php } ?>
<span> <i class="icofont-thumbs-up"></i> <?php
echo $thumbs_up=get_post_meta($post_id,'_thumbs_rating_up',true); ?></span>
</span>
</a></li>
<?php endwhile; else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
<div class="aside_box_content" style="display: none;" id="year_like3">
<ul class="aside_box_thu">
<?php global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => '_thumbs_rating_up',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '11 month ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>">
<?php if(has_post_thumbnail()){
the_post_thumbnail('thumb2',array('alt'=>''.get_the_title(),'title'=>''.get_the_title().'')); } else { ?>
<img src="<?php bloginfo('template_url');?>/images/music.jpg" width="50" height="50" alt="تصویر پیدا نشد" title="تصویر پیدا نشد"><?php } ?>
<?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true);
if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?>
<span class="sides_dets">
<?php if(function_exists('the_views')){ ?>
<span> <i class="icofont-eye-alt"></i> <?php the_views(); ?></span><?php } ?>
<span> <i class="icofont-thumbs-up"></i> <?php
echo $thumbs_up=get_post_meta($post_id,'_thumbs_rating_up',true); ?></span>
</span>
</a></li>
<?php endwhile; else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
</div>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title ='بیشترین لایک';
}
if ( isset( $instance[ 'post_numbers' ] ) ) {
$post_numbers = $instance[ 'post_numbers' ];
}
else {
$post_numbers = '7';
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان :</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_numbers' ); ?>">تعداد مطالب قابل نمایش:</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_numbers' ); ?>" name="<?php echo $this->get_field_name( 'post_numbers' ); ?>" type="text" value="<?php echo esc_attr( $post_numbers ); ?>" />
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'targets' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'targets' ); ?>" name="<?php echo $this->get_field_name( 'targets' ); ?>"/> 
<label for="<?php echo $this->get_field_id( 'targets' ); ?>">باز شدن لینک در تب جدید</label>
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_numbers'] = ( ! empty( $new_instance['post_numbers'] ) ) ? strip_tags( $new_instance['post_numbers'] ) : '';
$instance[ 'targets' ] = $new_instance[ 'targets' ];
return $instance;
}
}
// end like tab 2
function tab_ld_wet() { register_widget( 'tb_ir_por' ); }
add_action( 'widgets_init', 'tab_ld_wet' ); 
class tb_ir_por extends WP_Widget {
function __construct() {
parent::__construct(
'tb_ir_por', '(اختصاصی) موسیقی محبوب (لایک)', 
array('description' => 'ابزارک نمایش موسیقی های محبوب بر اساس لایک') 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title']);
$post_numbers = apply_filters( 'widget_numbers', $instance['post_numbers'] );
$targets = $instance[ 'targets' ] ? 'true' : 'false';
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<ul class='tabs-nav4'>
<li><a href="#week_lik1">هفته</a></li>
<li><a href="#month_lik2">ماه</a></li>
<li><a href="#year_lik3">سال</a></li>
</ul>
<div class="tabs-stage4">
<div class="aside_box_content" style="display: block;" id="week_lik1">
<ul>
<?php global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => '_thumbs_rating_up',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '1 week ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>"><?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?></a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
<div class="aside_box_content" style="display: none;" id="month_lik2">
<ul> 
<?php  global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => '_thumbs_rating_up',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '1 month ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>"><?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?></a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
<div class="aside_box_content" style="display: none;" id="year_lik3">
<ul>
<?php global $wp_query;
$arms = array(
'post_type' => 'post',
'posts_per_page' => $post_numbers,
'offset' => 0,
'meta_key'  => '_thumbs_rating_up',
'orderby' => 'meta_value_num',
'order' => 'DESC',
'post_status' => 'publish',
'date_query' => array(
array(
'column' => 'post_date_gmt',
'after' => '11 month ago',
)));
$wp_query = new WP_Query($arms);
if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); $post_id = $wp_query->post->ID; ?>
<li><a rel="noreferrer noopener" <?php if( $instance[ 'targets' ] == 'on' ){echo 'target="_blank" ';} ?>href="<?php the_permalink(); ?>"><?php $artist=get_post_meta($post_id,'artist',true); $track=get_post_meta($post_id,'song',true); if( (isset($artist) && !empty($artist)) || (isset($track) && !empty($track)) ){
 echo $artist; echo ' - '.$track; } else{ the_title(''); } ?></a></li>
<?php endwhile; wp_reset_postdata(); else : ?>
<li>چیزی برای نمایش وجود ندارد</li>
<?php endif; wp_reset_query(); ?>
</ul>
</div>
</div>
<?php
echo $args['after_widget'];
}
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title ='بیشترین لایک';
}
if ( isset( $instance[ 'post_numbers' ] ) ) {
$post_numbers = $instance[ 'post_numbers' ];
}
else {
$post_numbers = '7';
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>">عنوان :</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_numbers' ); ?>">تعداد مطالب قابل نمایش:</label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_numbers' ); ?>" name="<?php echo $this->get_field_name( 'post_numbers' ); ?>" type="text" value="<?php echo esc_attr( $post_numbers ); ?>" />
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'targets' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'targets' ); ?>" name="<?php echo $this->get_field_name( 'targets' ); ?>"/> 
<label for="<?php echo $this->get_field_id( 'targets' ); ?>">باز شدن لینک در تب جدید</label>
</p>
<?php 
}
public function update($new_instance,$old_instance){
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_numbers'] = ( ! empty( $new_instance['post_numbers'] ) ) ? strip_tags( $new_instance['post_numbers'] ) : '';
$instance[ 'targets' ] = $new_instance[ 'targets' ];
return $instance;
}
}
// end like tab