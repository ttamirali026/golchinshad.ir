<?php
/**
 * Initialize the options before anything else.
 */
add_action( 'admin_init', 'custom_theme_options', 1 );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( 'option_tree_settings', array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
'contextual_help' => array( 
'sidebar'=> ''
),
'sections'=> array( 
array('id'=>'general','title'=>'همگانی'),
array('id'=>'vips','title'=>'ویژه ها'),
array('id'=>'posts_d','title'=>'مطالب'),
array('id'=>'social','title'=>'شبکه های اجتماعی'),
array('id'=>'siing','title'=>'خواننده ها'),
array('id'=>'sidurl','title'=>'لینک دلخواه'),
array('id'=>'ads1','title'=>'تبلیغات'),
array('id'=>'footer','title'=>'پانوشت'),
),
'settings'=>array( 
// General
array(
'id'=>'s_layout',
'label'=>'طرح صفحات',
'desc'=>'حالت نمایش صفحات اصلی، دسته بندی، جستجو و برچسب ها را انتخاب کنید.',
'std'=>'sidebars',
'type'=>'radio-image',
'section'=>'general',
'choices'=>array( 
array(
'value'=>'sidebars',
'label'=>'dual sidebar',
'src'=>get_stylesheet_directory_uri().'/inc/option-tree/assets/images/layout/dual-sidebar.png'
),
array(
'value'=>'fullside',
'label'=>'full width',
'src'=>get_stylesheet_directory_uri().'/inc/option-tree/assets/images/layout/full-width.png'
))),
array(
'id'=>'favicon',
'label'=>'فاویکون',
'desc'=>'پیشنهاد می‌شود اندازه‌ی فاویکون 32px × 32px باشد.',
'std'=> get_stylesheet_directory_uri().'/images/favicon.png',
'type'=>'upload',
'section'=>'general'
),
array(
'id'=>'logo',
'label'=>'لوگو',
'desc'=>'پیشنهاد می‌شود اندازه‌ی لوگو 100px × 100px باشد.',
'std'=> get_stylesheet_directory_uri().'/images/logo.png',
'type'=>'upload',
'section'=>'general'
),
array(
'id'=>'scolor',
'label'=>'رنگبندی',
'desc'=>'رنگ بندی قالب را انتخاب کنید.',
'std'=>'#dd3333',
'type'=>'colorpicker',
'section'=>'general',
'operator'=>'and'
),
array(
'id'=>'mob_color',
'label'=>'منو موبایل',
'desc'=>'رنگ منو موبایل را انتخاب کنید.',
'std'=>'#dd3333',
'type'=>'colorpicker',
'section'=>'general',
'operator'=>'and'
),
array(
'id'=>'head_h1',
'label'=>'کلمه کلیدی',
'desc'=>'کلمه کلیدی ایندکس را وارد نمایید.',
'type'=>'text',
'std'=>'دانلود آهنگ جدید',
'section'=>'general'
),
array(
'id'=>'head_p',
'label'=>'توضیحات هدر',
'desc'=>'توضیحات هدر را وارد نمایید.',
'type'=>'text',
'std'=>'دانلود آهنگ جدید ایرانی',
'section'=>'general'
),
array(
'id'=>'timgi',
'label'=>'تصویرشاخص مطالب',
'desc'=>'تصویر شاخص در مطالب ایندکس و آرشیو (برای حالت سه ستونه) نمایش داده شود ؟',
'std'=>'off',
'type'=>'on-off',
'section'=>'general',
),
array(
'id'=>'timgi2',
'label'=>'تصویرشاخص مطالب',
'desc'=>'تصویر شاخص در صفحه دانلود آهنگ بالای متن ترانه و زیر محتوای اصلی نمایش داده شود ؟',
'std'=>'off',
'type'=>'on-off',
'section'=>'general',
),
array(
'id'=>'sun_moon',
'label'=>'حالت شب',
'desc'=>'امکان انتخاب حالت شب یا دارک مود نمایش داده شود؟',
'std'=>'on',
'type'=>'on-off',
'section'=>'general',
),
array(
'id'=>'dark_modes',
'label'=>'تم تاریک',
'desc'=>'تم تاریک به صورت پیشفرض فعال شود ؟',
'std'=>'off',
'type'=>'on-off',
'section'=>'general',
),
//posts_d
array(
'id'=>'ply_on',
'label'=>'پلیر مطالب ایندکس',
'desc'=>'پلیر مطالب در صحفه اصلی نمایش داده شود ؟',
'std'=>'on',
'type'=>'on-off',
'section'=>'posts_d',
),
array(
'id'=>'ply1_on',
'label'=>'پلیر مطالب آرشیو',
'desc'=>'پلیر مطالب در صفحات آرشیو نمایش داده شود ؟',
'std'=>'on',
'type'=>'on-off',
'section'=>'posts_d',
),
//vips
array(
'id'=>'vipon',
'label'=>'نمایش باکس ویژه ها',
'desc'=>'امکان مطالب ویژه نمایش داده شود؟',
'std'=>'on',
'type'=>'on-off',
'section'=>'vips',
),
array(
'id'=>'vip_title',
'label'=>'عنوان باکس ویژه',
'desc'=>'عنوان باکس ویژه را وارد نمایید.',
'type'=>'text',
'std'=>'ویژه ها',
'section'=>'vips'
),
array(
'id'=>'ftcat1',
'label'=>'دسته بندی',
'desc'=>'دسته بندی مطالب ویژه را انتخاب کنید.',
'std'=>'',
'type'=>'category-select',
'section'=>'vips'
),
array(
'id'=>'ft_num',
'label'=>'تعداد مطالب',
'desc'=>'تعداد مطالب ویژه قابل نمایش را انتخاب کنید.',
'std'=>'6',
'type'=>'text',
'section'=>'vips'
),
// social
array(
'id'=>'fixbtn',
'label'=>'لینکهای ثابت',
'desc'=>'لینکهای تلگرام  و اینستاگرام  به شکل ثابت نمایش داده شوند ؟',
'std'=>'on',
'type'=>'on-off',
'section'=>'socials',
),
array(
'id'=>'insteleg',
'label'=>'اینستاگرام و تلگرام سینگل',
'desc'=>'اینستاگرام و تلگرام در بالای لینک دانلود سینگل یا همان صفحه دانلود آهنگ نمایش داده شود؟',
'std'=>'on',
'type'=>'on-off',
'section'=>'social',
),
array(
'id'=>'insta_tx',
'label'=>'اینستاگرام',
'desc'=>'متن لینک اینستاگرام در ادامه مطلب را وارد کنید.',
'type'=>'text',
'std'=>'اینستاگرام ماه موزیک',
'section'=>'social'
),
array(
'id'=>'insta',
'label'=>'اینستاگرام',
'desc'=>'آدرس صفحه اینستاگرام را به همراه http:// وارد نمایید.',
'type'=>'text',
'std'=>'',
'section'=>'social'
),
array(
'id'=>'teleg_tx',
'label'=>'تلگرام',
'desc'=>'متن لینک تلگرام در ادامه مطلب را وارد کنید.',
'type'=>'text',
'std'=>'تلگرام ماه موزیک',
'section'=>'social'
),
array(
'id'=>'teleg',
'label'=>'تلگرام',
'desc'=>'آدرس صفحه تلگرام را به همراه http:// وارد نمایید.',
'type'=>'text',
'std'=>'',
'section'=>'social'
),
array(
'id'=>'youti',
'label'=>'یوتیوب',
'desc'=>'آدرس صفحه یوتیوب را به همراه http:// وارد نمایید.',
'type'=>'text',
'std'=>'',
'section'=>'social'
),
//footer
array(
'id'=>'copy_right',
'label'=>'کپی رایت',
'desc'=>'متن کپی رایت را وارد نمایید.',
'type'=>'text',
'std'=>'کلیه حقوق مادی و معنوی برای مدیران سایت محفوظ است.',
'section'=>'footer'
),
// siing
array(
'id'=>'siing_t',
'label'=>'خواننده ها',
'desc'=>'لیست خواننده ها را ایجاد کنید.',
'type'=>'list-item',
'section'=>'siing',
'choices'=>array(),
'settings'=>array(
array(
'id'=>'siing_u',
'label'=>'صفحه خواننده',
'desc'=>'آدرس صفحه خواننده را به همراه http:// را وارد کنید.',
'std'=> '',
'type'=>'text',
'choices'=>array()
))),
// sidurl
array(
'id'=>'sid_url',
'label'=>'لینکهای دلخواه',
'desc'=>'لیست لینکهای دلخواه قابل نمایش در ستون کناری را ایجاد کنید.',
'type'=>'list-item',
'section'=>'sidurl',
'choices'=>array(),
'settings'=>array(
  array(
'id'=>'si_icon',
'label'=>'آیکون',
'desc'=>'نام ایکون دلخواه را وارد کنید. <a target="_blank" rel="nofollow" href="http://rkianoosh.ir/icon/">لیست آیکونها</a>',
'std'=> 'music',
'type'=>'text',
'choices'=>array()
),
array(
'id'=>'si_u',
'label'=>'آدرس',
'desc'=>'آدرس صفحه را به همراه http:// را وارد کنید.',
'std'=> '',
'type'=>'text',
'choices'=>array()
))),
//ads1
array(
'id'=>'ads_imp',
'label'=>'تبلیغات بنری زیر هدر',
'desc'=>'بنرهای تبلیغاتی زیر هدر را وارد کنید. نکته: از تصویر به همراه لینک استفاده کنید.',
'type'=>'textarea',
'std'=>'',
'section'=>'ads1'
),
array(
'id'=>'ads_tp',
'label'=>'تبلیغات بالای مطالب',
'desc'=>'کد تبلیغاتی قابل نمایش در بالای مطالب را وارد کنید.',
'type'=>'textarea',
'std'=>'',
'section'=>'ads1'
),
array(
'id'=>'ads_bt',
'label'=>'تبلیغات پایین مطالب',
'desc'=>'کد تبلیغاتی قابل نمایش در پایین مطالب را وارد کنید.',
'type'=>'textarea',
'std'=>'',
'section'=>'ads1'
),
array(
'id'=>'ads_sg',
'label'=>'تبلیغات بالای لینک دانلود',
'desc'=>'کد تبلیغاتی قابل نمایش در بالای لینکهای دانلود را وارد کنید.',
'type'=>'textarea',
'std'=>'',
'section'=>'ads1'
),
array(
'id'=>'txt_ads',
'label'=>'تبلیغات متنی',
'desc'=>'لیست تبلیغات متنی را ایجاد کنید.',
'type'=>'list-item',
'section'=>'ads1',
'choices'=>array(),
'settings'=>array(
array(
'id'=>'tads_url',
'label'=>'آدرس',
'desc'=>'آدرس سایت را به همراه http:// وارد کنید.',
'std'=> '',
'type'=>'text',
'choices'=>array()
))),
	
	
	
	

));
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( 'option_tree_settings_args', $custom_settings );
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( 'option_tree_settings', $custom_settings ); 
  }
}
