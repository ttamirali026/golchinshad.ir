<!-- mobile headers -->
<div id="mobiles_header">
<div class="navicon"><i class="icofont-navigation-menu"></i></div> 
<div class="logo_mobiles"><figure>
<a rel="noreferrer noopener" href="<?php bloginfo('url'); ?>"><img src="<?php echo ot_get_option('logo'); ?>" width="100" height="100" alt="<?php echo ot_get_option('head_h1'); ?>" title="<?php echo ot_get_option('head_h1'); ?>"></a>
</figure></div>
<!-- searches_mobile -->
<form class="searches_mobile" method="get" action="<?php bloginfo('url'); ?>">
<label><span>جستجو</span>
<input id="lsds_mobile" name="s" placeholder="کلمه مورد نظر ..." type="text"></label>
<button aria-label="search"><i class="icofont-search"></i></button>
</form>
<!-- searches_mobile -->
<div class="circle_hlink search_mobile_box"><i class="icofont-search"></i></div>
<?php $enablepop = ot_get_option('sun_moon'); if('off' != $enablepop){ ?>
<div class="dark_light_mode<?php $darks = ot_get_option('dark_modes'); if('off' != $darks){echo ' dark_active'; } ?>">
<i class="icofont-moon"></i><div class="toggle_modes"></div><i class="icofont-sun"></i></div><?php } ?>
<!-- mobile menus -->
<div class="mobile_box">
<div class="bodydeactive"></div>
<div class="mobiles_menu">
<!-- top_logo_title -->
<div class="top_logo_title">
<a rel="noreferrer noopener" href="<?php bloginfo('url'); ?>"><img src="<?php echo ot_get_option('logo'); ?>" width="100" height="100" alt="<?php echo ot_get_option('head_h1'); ?>" title="<?php echo ot_get_option('head_h1'); ?>"></a>
<div class="clear"></div>
</div>
<!-- top_logo_title -->
<?php wp_nav_menu(array('theme_location'=>'mobiles_menu','container_id'=>'cssmenu','walker'=>new CSS_Menu_Maker_Walker())); ?>
</div>
</div>
</div>
<!-- mobile menus -->