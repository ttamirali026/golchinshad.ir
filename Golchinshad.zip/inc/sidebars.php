<!-- center_boxes -->
<div class="tarlanweb_center">
<div id="center_boxes">
<?php get_sidebar('right'); ?>
<!-- center_content -->
<div id="center_content">
<?php if(is_category()){ ?> 
<div class="article_box cats_dets padding15">
<h1><?php echo single_cat_title(''); ?></h1>
<div class="article_box_txtc">
<?php echo category_description(); ?>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<?php } ?>
<?php if(is_search()){ ?> 
<div class="article_box cats_dets padding15">
<h1>نتایج جستجو عبارت : <?php printf(the_search_query()); ?></h1>
<div class="clear"></div>
</div>
<?php } ?>
<?php if(is_tag()){ ?>
<div class="article_box cats_dets padding15">
<h1><?php echo single_tag_title(''); ?></h1>
<div class="article_box_txtc">
<?php echo tag_description(); ?>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<?php } ?>
<?php if(!is_home()){get_template_part('inc/breadcrumbs');} ?>
<?php if(ot_get_option('ads_tp') !=""){ ?>
<div class="article_box padding15">
<?php echo ot_get_option('ads_tp'); ?>
<div class="clear"></div>
</div>
<?php } ?>
<?php if(have_posts()) : while(have_posts()) : the_post(); get_template_part('inc/posts'); endwhile;
else: get_template_part('inc/error-content'); endif; ?>
<?php if(ot_get_option('ads_bt') !=""){ ?>
<div class="article_box padding15">
<?php echo ot_get_option('ads_bt'); ?>
<div class="clear"></div>
</div>
<?php } ?>	
<?php get_template_part('inc/pagination'); ?>
<div class="clear"></div>
</div>
<!-- center_content -->
<?php get_sidebar('left'); ?>
<div class="clear"></div>
</div>
</div>
<!-- center_boxes -->